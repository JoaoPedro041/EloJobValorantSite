fetch("../carrinho/carrinho.php", { 
    method: "GET" 
}).then(async function (resposta) {
    var objeto = await resposta.json();
    precoTotal(objeto);
});


function salvarPagamentoCartao(){
  var objetoForm = document.getElementById('formPagamento');
  var dados = new FormData(objetoForm);

  


  if(document.getElementById("nome_cartao").value !="" &&
     document.getElementById("numero_cartao").value !="" &&
     document.getElementById("data_validade").value !="" &&
     document.getElementById("cvv").value !=""){

      
          fetch("pagamento.php",{
          method: "POST",
          body: dados
          },

          
      ); 
      alert("Compra Realizada! Agradecemos a preferência!");
  }
      else{

          alert("Preencha todos os campos!");

      }
}


function salvarPagamentoPIX(){
    var objetoForm = document.getElementById('formPagamento');
    var dados = new FormData(objetoForm);
  
    {

            fetch("pagamento.php",{
            method: "POST",
            body: dados
            },
  
            
        ); 
        
    alert("Compra Realizada! Agradecemos a preferência!");
    window.location.href = "../paginaprincipal/pagPrinc.html";
    
  }
}

function precoTotal(objeto){

    let precoJs;

    precoJs = 0;

    for(var i = 0; i < objeto.length; i++){
        
        precoJs += parseFloat(objeto[i].preco);

}

    document.getElementById("TotalPagar").innerHTML += 'Total à pagar:' + ' ' + precoJs;
    document.getElementById('total_pago').value = precoJs;
    document.getElementById('data_pagamento').value = Date();
}


