<?php

    include "conexao.php";

    $nome_cartao= $_POST["nome_cartao"];
    $numero_cartao= $_POST["numero_cartao"];
    $data_validade= $_POST["data_validade"];
    $cvv= $_POST["cvv"];
    $tipo_pagamento = $_POST["tipo_pagamento"];
    $total_pago = $_POST["total_pago"];
    $data_pagamento = $_POST["data_pagamento"];



    $query = "INSERT INTO pagamento(nome_cartao, numero_cartao, data_validade, cvv, tipo_pagamento, data_pagamento, total_pago) VALUES('$nome_cartao','$numero_cartao','$data_validade','$cvv','$tipo_pagamento', '$data_pagamento', '$total_pago')";

    mysqli_query($conexao, $query);

    $objetoJSON = json_encode($resposta);
    echo $objetoJSON;


?>