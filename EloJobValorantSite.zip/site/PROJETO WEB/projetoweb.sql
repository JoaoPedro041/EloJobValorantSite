-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: projetoweb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cadastro`
--

DROP TABLE IF EXISTS `cadastro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cadastro` (
  `id_cadastro` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `cpf` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_cadastro`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cadastro`
--

LOCK TABLES `cadastro` WRITE;
/*!40000 ALTER TABLE `cadastro` DISABLE KEYS */;
INSERT INTO `cadastro` VALUES (1,'gui17','gui17','gdaudt17@gmail.com','03978013002'),(2,'guilherme','guilherme','guilherme','guilherme'),(3,'a','a','a','a'),(4,'qq','qq','qqq','qqq'),(5,'','','',''),(6,'','','',''),(7,'Vinicius','123456','viniguidottireal@gmail.com','11111111111'),(8,'aa','aa','aa','aa'),(9,'joaomaronezi','123456','joaotofdd8@hotmail.com','1234567891'),(10,'a','a','viniguidottireal@gmail.com','a'),(11,'aaaa','aaaa','viniguidottireal@gmail.com','aaaa');
/*!40000 ALTER TABLE `cadastro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carrinho`
--

DROP TABLE IF EXISTS `carrinho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carrinho` (
  `id_produto` int NOT NULL,
  `id_carrinho` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_carrinho`),
  KEY `id_produto` (`id_produto`),
  CONSTRAINT `carrinho_ibfk_1` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrinho`
--

LOCK TABLES `carrinho` WRITE;
/*!40000 ALTER TABLE `carrinho` DISABLE KEYS */;
INSERT INTO `carrinho` VALUES (1,66),(2,67),(3,68);
/*!40000 ALTER TABLE `carrinho` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagamento`
--

DROP TABLE IF EXISTS `pagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagamento` (
  `nome_cartao` varchar(100) DEFAULT NULL,
  `numero_cartao` varchar(20) DEFAULT NULL,
  `data_validade` date DEFAULT NULL,
  `cvv` int DEFAULT NULL,
  `id_pagamento` int NOT NULL AUTO_INCREMENT,
  `total_pago` float DEFAULT NULL,
  `data_pagamento` varchar(200) DEFAULT NULL,
  `tipo_pagamento` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_pagamento`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagamento`
--

LOCK TABLES `pagamento` WRITE;
/*!40000 ALTER TABLE `pagamento` DISABLE KEYS */;
INSERT INTO `pagamento` VALUES ('aa','11','0111-11-11',111,1,0,'0000-00-00',''),('0','0','0000-00-00',0,2,0,'0000-00-00','PIX'),('0','0','0000-00-00',0,3,10857,'0000-00-00','PIX'),('0','0','0000-00-00',0,4,10857,'0000-00-00','PIX'),('0','0','0000-00-00',0,5,10857,'1667764340485','PIX'),('0','0','0000-00-00',0,6,10857,'','PIX'),('0','0','0000-00-00',0,7,10857,'','PIX'),('0','0','0000-00-00',0,8,10857,'Sun Nov 06 2022 16:54:32 GMT-0300 (Horário Padrão de Brasília)','PIX'),('matheus','1111111','2022-01-01',123,9,10857,'Sun Nov 06 2022 17:01:57 GMT-0300 (Horário Padrão de Brasília)','DEBITO'),('Lucato','1234 5678 4356 9347','2022-12-01',666,10,10857,'Sun Nov 06 2022 17:05:30 GMT-0300 (Horário Padrão de Brasília)','DEBITO'),('Lucato teste final DEBITO','1234 5678 2341 1234','2022-09-28',123,11,10857,'Sun Nov 06 2022 17:08:36 GMT-0300 (Horário Padrão de Brasília)','DEBITO'),('LUCATO TESTE FINAL CREDITO','1234 2984 1239 5432','2022-09-09',321,12,10857,'Sun Nov 06 2022 17:10:28 GMT-0300 (Horário Padrão de Brasília)','CREDITO'),('0','0','0000-00-00',0,13,10857,'Sun Nov 06 2022 17:15:11 GMT-0300 (Horário Padrão de Brasília)','PIX');
/*!40000 ALTER TABLE `pagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id_produto` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `sub_nome` varchar(45) DEFAULT NULL,
  `valor` float NOT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `descricao` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Dell G15 ','Notebook Gamer',5399,'Laptops & Notebooks','Fique totalmente imerso em todas as experiências graças à renderização suave de placas gráficas dedicadas até NVIDIA® GeForce RTX™ 3060 e as cores vívidas do painel de exibição FHD de até 165 Hz com 300 nits com bordas estreitas em três lados. Além disso, com até 6 GB de GDDR6 de memória dedicada, você pode experimentar uma ação incrível com tempos de carregamento menores e um sistema mais silencioso.'),(2,'Camiseta Hering Básica Masculina','Super Cotton',59,'Roupas e Acessórios','O modelo conta com uma modelagem regular, proporcionando um caimento solto ao corpo, gola redonda e mangas curtas. A peça não possui costuras laterais trazendo mais conforto e satisfação ao vestir. Com ampla cartela de cores, aposte nesse modelo clássico e indispensável no guarda-roupa. Invista em você!'),(3,'Máscara (Rímel)','Máximo Alongamento',79,'Beleza e Maquiagem','A Máscara para Cílios By Femme É tratamento para Cílios, possui fórmula polímeros 3D, com Pantenol e Vitamina E. Dessa forma, além de alongar, ajuda a dar volume nos cílios, garantindo um olhar muito mais expressivo. A melhor experiência da sua vida sem efeito panda. \"Best Seller\"Alta fixação & fácil Remoção você pode praticar atividades físicas, correr maratona, virar atriz de velório sem efeito panda.Ao aplicar a máscara ela forma uma cápsula protetora onde irá hidratar e prevenir os fios dos Cílios durando o dia todo, na remoção com água morna no banho ou com demaquilante ela solta a cápsula em cubinhos trazendo maior conforto e praticidade para o seu dia a dia.'),(4,'Chuteira Nike ','Phantom GT2 Elite Campo',899,'Artigos Esportivos','Continuando o legado da Phantom GT, a Nike Phantom GT2 Elite FG apresenta um design atualizado e um padrão em relevo projetado para otimizar seus movimentos e controlar o voo da bola. Os cadarços descentralizados criam uma zona de chute livre de obstáculos para chutes, passes e dribles habilidosos.'),(5,'Fritadeira Air Fry Britânia ','Pro Saúde Preta',349,'Cozinha e Eletrodomesticos','O que era inimaginável agora é real, sim, você pode fritar alimentos sem usar óleo, sem deixar cheiro de gordura ou fumaça pela casa, e tem mais, você também pode preparar alimentos de maneira incrivelmente rápida e deixar tudo crocante, gostoso e mais saudável para a sua família! Com a incrível Fritadeira Elétrica Sem Óleo Air Fryer AF-31 New Pratic Preta da Mondial feita em PP, com capacidade total de 3,6L, tudo isso está ao seu alcance. Painel digital touch screen que facilita a escolha das funções de tempo e temperatura, lâmpadas-piloto que indicam o funcionamento do produto e do aquecimento, controle de temperatura até 200 oC para a escolha da temperatura ideal de acordo com diferentes tipos de alimentos..'),(6,'Teclado Gamer Mecânico','Hoopson Branco RGB',199,'Laptops & Notebooks','Um Teclado de alto desempenho permite que você desfrute de horas ilimitadas de jogos. Foi especialmente desenvolvido para que você possa expressar suas habilidades e seu estilo. Melhore a sua experiência de jogo, seja você um amador ou um especialista.'),(7,'Panela Redonda','Signature Le Creuset',1499,'Cozinha e Eletrodomesticos','Icônica, a panela Le Creuset Redonda Signature é um clássico da marca e indispensável para sua casa.'),(8,'Iphone 13','256gb',7459,'Smartphones','Phone 13. O sistema de câmera dupla mais avançado em um iPhone. Chip A15 Bionic com velocidade impressionante. Um grande salto em bateria. Projetado para durar. 5G ultrarrápido*. E tela Super Retina XDR mais brilhante. Avisos legais: *É preciso ter um plano de dados. 5G só está disponível em alguns países e por meio de determinadas operadoras. As velocidades variam de acordo com as condições e operadoras locais. Para obter detalhes sobre a compatibilidade com 5G, entre em contato com sua operadora e consulte apple.com/br/iphone/cellular.'),(9,'Kit Fortificante Capilar','Com Shampoo e Máscara',349,'Beleza e Maquiagem','O Kit de Alho promove o fortalecimento e reparação profunda dos cabelos de dentro para fora. É a combinação perfeita e equilibrada de ativos naturais que auxiliam no crescimento saudável dos cabelos. Liberado para LOW POO.');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'projetoweb'
--

--
-- Dumping routines for database 'projetoweb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-06 17:39:27
