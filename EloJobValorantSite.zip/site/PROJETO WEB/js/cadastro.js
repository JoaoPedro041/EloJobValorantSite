function salvar(){
    var objetoForm = document.getElementById('formCadastro');
    var dados = new FormData(objetoForm);

    


    if(document.getElementById("usuariocadastro").value !="" &&
       document.getElementById("senhacadastro").value !="" &&
       document.getElementById("confirmarsenhacadastro").value !="" &&
       document.getElementById("emailcadastro").value !="" &&
       document.getElementById("cpfcadastro").value !=""){

        if(document.getElementById("senhacadastro").value ==
           document.getElementById("confirmarsenhacadastro").value ){

            fetch("php/cadastro.php",{
            method: "POST",
            body: dados

        })
            window.location.href = "index.html";
        }

        else{

            alert("O campo Senha é diferente do Confirmar Senha");

        }
        

    }else{
        alert("Preencha TODOS os campos ");
    }

}