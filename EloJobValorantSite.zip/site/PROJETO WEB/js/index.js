function entrar(){
    var obejetoForm = document.getElementById('formEntrar');
    var dados = new FormData(obejetoForm);


    if(document.getElementById("usariologin") !="" &&
       document.getElementById("senhalogin") !=""){

        fetch("php/index.php",{
            method: "POST",
            body: dados
        }).then(async function(resposta){

            var objeto = await resposta.json();
    
            if(objeto.status == "s"){
    
                window.location.href = "paginaprincipal/pagPrinc.html";
                
            }
            else{
    
                alert("Usúario NÃO cadastrado");
    
            }
        });

    }

}

