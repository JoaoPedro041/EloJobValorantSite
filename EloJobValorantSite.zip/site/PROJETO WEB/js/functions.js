function salvar(){
    var objetoForm = document.getElementById('formCadastro');
    var dados = new FormData(objetoForm);


    if(document.getElementById("usuarioCadastro") !="" &&
       document.getElementById("emailCadastro") !="" &&
       document.getElementById("senhaCadastro") !=""){

        fetch("php/index.php",{
            method: "POST",
            body: dados
        })

    }else{
        alert("Preencha TODOS os campos ");
    }

}

function entrar(){
    var obejetoForm2 = document.getElementById('formEntrar');
    var dados2 = new FormData(obejetoForm2);


    if(document.getElementById("login") !="" &&
       document.getElementById("senha") !=""){

        fetch("php/index2.php",{
            method: "POST",
            body: dados2
        })

        

    }else{
        alert("Preencha TODOS os campos ");
    }

}

