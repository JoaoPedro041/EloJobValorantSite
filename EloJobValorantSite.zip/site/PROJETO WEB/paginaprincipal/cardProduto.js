
fetch("cardProduto.php",{
    method: "GET",
}).then(async function(resposta){
    
    var objeto = await resposta.json();
   
    listarProdutos(objeto);

});

function listarProdutos(objeto){

    for(var i=0; i < objeto.length; i++){

        var conteudo = "";

        var numeroRandomReviews = Math.floor(Math.random() * 10000);
        var numeroRandomEstoque = Math.floor(Math.random() * 500);

        conteudo += '<div class="col-md-4 mt-2">';                  
        conteudo += '<div class="cardz">';
        conteudo += '<div class="cardz-body">';
        conteudo += '<div class="cardz-img-actions">';
        conteudo += '<img src="../imagens/'+ objeto[i].id_produto +'.png" class="cardz-img img-fluid" width="96" height="350" alt="">'; 
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '<div class="cardz-body bg-light text-center">';
        conteudo += '<div class="mb-2">';
        conteudo += '<h6 class="font-weight-semibold mb-2">';
        conteudo += objeto[i].nome + ' ' + objeto[i].sub_nome;
        conteudo += '</h6>';
        conteudo += objeto[i].tipo;
        conteudo += '</div>';
        conteudo += '<h3 class="mb-0 font-weight-semibold">'+ objeto[i].valor + '</h3>';
        conteudo += '<div class="text-muted mb-3">' + numeroRandomReviews + ' reviews<br>'+ numeroRandomEstoque + ' no estoque</div>';
        conteudo += '<a href="../paginaProdutos/pagProdutos.html"><button type="button" class="btn bg-cart" style="background-color:#1b2850; color: white;"><i class="fa fa-cart-plus mr-2" style="padding-right: 7px"></i>Pagina do Produto!</button></a>';                        
        conteudo += '</div>';
        conteudo += '</div>';                            
        conteudo += '</div>';

        document.getElementById("divListar").innerHTML += conteudo;

        
    }

}
