
    fetch("autoria.php",{
    method: "GET",
}).then(async function(resposta){

    var objeto = await resposta.json();
    
console.log("Usuários: ")

for(var i=0; i < objeto.length; i++){

    console.log(objeto[i].usuario + ": " + objeto[i].email);}
   
 
});




