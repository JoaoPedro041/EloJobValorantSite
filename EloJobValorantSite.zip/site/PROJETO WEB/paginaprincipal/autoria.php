<?php

    include"conexao.php";
    
    $query = "SELECT * FROM cadastro";

    $registros = mysqli_query($conexao, $query);

    $i = 0;

    while($registro = mysqli_fetch_assoc($registros)){

        $resposta[$i]["usuario"] = $registro["usuario"];
        $resposta[$i]["email"] = $registro["email"];
      
        $i++;
    }
    
    echo($registro);

    $objetoJSON = json_encode($resposta);
    echo $objetoJSON;

?>