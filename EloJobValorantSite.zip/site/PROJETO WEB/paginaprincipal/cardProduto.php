<?php

    include"conexao.php";
    
    $query = "SELECT * FROM produtos";

    $registros = mysqli_query($conexao, $query);

    $i = 0;

    while($registro = mysqli_fetch_assoc($registros)){

        $resposta[$i]["id_produto"] = $registro["id_produto"];
        $resposta[$i]["nome"] = $registro["nome"];
        $resposta[$i]["sub_nome"] = $registro["sub_nome"];
        $resposta[$i]["valor"] = $registro["valor"];
        $resposta[$i]["tipo"] = $registro["tipo"];
        $resposta[$i]["descricao"] = $registro["descricao"];

        $i++;
    }
    
    $objetoJSON = json_encode($resposta);
    echo $objetoJSON;

?>