<?php

    include "conexao.php";

    $id_produto = $_POST["id_produto"];

    $query = "INSERT INTO carrinho(id_produto) VALUES ($id_produto)";

    mysqli_query($conexao, $query);

?>