

fetch("PagProduto.php",{
    method: "GET",
}).then(async function(resposta){
    
    var objeto = await resposta.json();
   
    listarProdutos(objeto);

});

function listarProdutos(objeto){

    for(var i=0; i < objeto.length; i++){

        var conteudo = "";

        conteudo += '<main style="margin-top: 40px;">';
        conteudo += '</nav>';
        conteudo += '<div class="card">';
        conteudo += '<div class="card__title" >';
        conteudo += '<div class="icon" style="display: block;">';
        conteudo += '</div>';
        conteudo += '<h3>' + objeto[i].tipo +'</h3>';
        conteudo += '</div>';
        conteudo += '<div class="card__body">';
        conteudo += '<div class="half">';
        conteudo += '<div class="featured_text">';
        conteudo += '<h1>'+ objeto[i].nome +'</h1>';
        conteudo += '<p class="sub">'+ objeto[i].sub_nome +'</p>';
        conteudo += '<p class="price">'+ objeto[i].valor +'</p>';
        conteudo += '</div>';
        conteudo += '<div class="image">';
        conteudo += '<img src="../imagens/'+ objeto[i].id_produto +'.png" >';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '<div class="half">';
        conteudo += '<div class="description">';
        conteudo += '<p>'+ objeto[i].descricao +'</p>';
        conteudo += '</div>';
        conteudo += '<span class="stock"><i class="fa fa-pen"></i> Pronta entrega!</span>';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '<div class="card__footer">';
        conteudo += '<div class="recommend">';
        conteudo += '<p>Você merece o que há de melhor!</p>';
        conteudo += '<h3>Arcadez</h3>';
        conteudo += '</div>';
        conteudo += '<div class="action">';
        conteudo += '<button type="button" onclick="comprar(' + objeto[i].id_produto + ')">Adicione ao Carrinho</button>';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '<div style="visibility: hidden;">.</div>';
        conteudo += '<div style="visibility: hidden;">.</div>';
        conteudo += '</main>';

        
        document.getElementById("divListar").innerHTML += conteudo;

    }

}

function comprar(id_produto){

    document.getElementById("id_produto").value = id_produto;
    var form = document.getElementById("formCarrinho");
    var dados = new FormData(form);
    
    fetch("addcarrinho.php",{
    method: "POST",
    body :dados
    });

    alert("Item adicionado ao carrinho!");
}