<?php

    include "conexao.php";

    $email = $_POST['emaillogin'];
    $senha = $_POST['senhalogin'];

    $query = "SELECT * FROM cadastro WHERE email = '$email' AND senha = '$senha'";

    $resultado = mysqli_query($conexao, $query);
    
    if (mysqli_num_rows($resultado) > 0){

        $retorno["status"] = "s";

    }
    else{

        $retorno["status"] = "n";

    }

    $objetoJSON = json_encode($retorno);
    echo $objetoJSON;

?>