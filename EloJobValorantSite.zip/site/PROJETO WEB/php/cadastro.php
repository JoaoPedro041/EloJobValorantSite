<?php

    include "conexao.php";

    $usuario= $_POST["usuariocadastro"];
    $senha = $_POST["senhacadastro"];
    $email= $_POST["emailcadastro"];
    $cpf = $_POST["cpfcadastro"];
    
    $query = "INSERT INTO cadastro(usuario, senha, email, cpf) VALUES('$usuario','$senha','$email','$cpf')";
    
    mysqli_query($conexao, $query);



?>