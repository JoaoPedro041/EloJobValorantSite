fetch("carrinho.php", { 
    method: "GET" 
}).then(async function (resposta) {
    var objeto = await resposta.json();
    listarProdutos(objeto);
});

function listarProdutos(objeto){

    let precoJs;

    precoJs = 0;

    for(var i = 0; i < objeto.length; i++){
        
        precoJs += parseFloat(objeto[i].preco);

        var conteudo = '';
        conteudo += '<br>';
        conteudo += '<form id="formCarrinho">';
        conteudo += '<div class="row">';
        conteudo += '<div class="col-lg-7">';
        conteudo += '<div class="bg-image hover-overlay hover-zoom ripple rounded" data-mdb-ripple-color="light" style="margin-left: 10px;">';
        conteudo += '<img src="../imagens/'+ objeto[i].id_produto +'.png" class="w-100" />'; 
        conteudo += '<div class="mask" style="background-color: rgba(251, 251, 251, 0.2)"></div>';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '<div class="col-lg-5 col-md-6 mb-4 mb-lg-0">';
        conteudo += '<p style="color:black; margin-top: 30px; padding-right:10px;"><strong>' + objeto[i].nome + '</strong></p>';
        conteudo += '<p style="color:black;">' + objeto[i].sub_nome + '</p>';
        conteudo += '<button type="button" style="width: 60px; height: 25px;" class="btn btn-primary btn-sm me-1 mb-2" onclick="cancelar(' + objeto[i].id_produto + ')" data-mdb-toggle="tooltip" title="Remove item">';
        conteudo += '<i class="fas fa-trash"></i>';
        conteudo += '</button>';
        conteudo += '<button type="button" style="width: 60px; height: 25px;" class="btn btn-danger btn-sm mb-2" onclick="curtida()" data-mdb-toggle="tooltip">';
        conteudo += '<i class="fas fa-heart"></i>';
        conteudo += '</button>';
        conteudo += '<div class="col-6">';
        conteudo += '<h5 style="margin-top: 10px; color:green"><strong>' + objeto[i].preco + '</strong></h5>';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '<div class="col-lg-4 col-md-6 mb-4 mb-lg-0">';
        conteudo += '<div class="d-flex mb-4" style="max-width: 100px">';
        conteudo += '<div class="form-outline">';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '</div>';
        conteudo += '</form>';
        conteudo += '<div class="card-body">';
        conteudo += '<hr class="my-3" />';

        //conteudoPreco = '<span><strong>'+ preco +'</strong></span>';       
        document.getElementById("listarCarrinho").innerHTML += conteudo;
        //document.getElementById("precoTotal").innerHTML += conteudoPreco;  

    }

    document.getElementById("precoTotal").innerHTML += precoJs;
    

}

function cancelar(id_produto){

    document.getElementById("id_produto").value = id_produto;
    var form = document.getElementById("formCarrinho");
    var dados = new FormData(form);

    fetch("Delcarrinho.php", {
        method: "POST",
        body: dados
    });

    location.reload();
    
}


function curtida(){
    alert("Pronto! Este item foi adicionado nos favoritos!");
}

function irTelaPagamento(){
    if(document.getElementById("formCarrinho").length > 1){
        window.location.href = "../paginaPagamento/paginaMenuPagamento.html";
    
    }
    else{
        alert("Nenhum item no seu carrinho, estamos te direcionando para a pagina de compras!");
        window.location.href = "../paginaProdutos/pagProdutos.html";
    }
}


