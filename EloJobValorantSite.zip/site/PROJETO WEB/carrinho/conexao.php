<?php

    $conexao = mysqli_connect("localhost:3306","root","root","projetoweb");

?>