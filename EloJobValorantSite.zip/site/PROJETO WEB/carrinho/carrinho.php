<?php

    include "conexao.php";

    $query = "SELECT * FROM carrinho as c inner join produtos on c.id_produto = produtos.id_produto";
    $registros = mysqli_query($conexao, $query);

    $i = 0;

    while($registro = mysqli_fetch_assoc($registros)){

        $resposta[$i]["id_produto"] = $registro["id_produto"];
        $resposta[$i]["nome"] = $registro["nome"];
        $resposta[$i]["preco"] = $registro["valor"];
        $resposta[$i]["sub_nome"] = $registro["sub_nome"];

        
        $i++;
    }

    $objetoJSON = json_encode($resposta);
    echo $objetoJSON;

?>