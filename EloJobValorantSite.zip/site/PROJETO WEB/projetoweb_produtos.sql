-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: projetoweb
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id_produto` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `sub_nome` varchar(45) DEFAULT NULL,
  `valor` varchar(45) DEFAULT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `descricao` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Dell G15 ','NOTEBOOK GAMER','5.399','Laptops & Notebooks','Fique totalmente imerso em todas as experiências graças à renderização suave de placas gráficas dedicadas até NVIDIA® GeForce RTX™ 3060 e as cores vívidas do painel de exibição FHD de até 165 Hz com 300 nits com bordas estreitas em três lados. Além disso, com até 6 GB de GDDR6 de memória dedicada, você pode experimentar uma ação incrível com tempos de carregamento menores e um sistema mais silencioso.'),(2,'Camiseta Hering Básica Masculina','Super Cotton','59','Roupas e Acessórios','O modelo conta com uma modelagem regular, proporcionando um caimento solto ao corpo, gola redonda e mangas curtas. A peça não possui costuras laterais trazendo mais conforto e satisfação ao vestir. Com ampla cartela de cores, aposte nesse modelo clássico e indispensável no guarda-roupa. Invista em você!'),(3,'Máscara (Rímel)','Máximo Alongamento','79','Beleza e Maquiagem','A Máscara para Cílios By Femme É tratamento para Cílios, possui fórmula polímeros 3D, com Pantenol e Vitamina E. Dessa forma, além de alongar, ajuda a dar volume nos cílios, garantindo um olhar muito mais expressivo. A melhor experiência da sua vida sem efeito panda. \"Best Seller\"Alta fixação & fácil Remoção você pode praticar atividades físicas, correr maratona, virar atriz de velório sem efeito panda.Ao aplicar a máscara ela forma uma cápsula protetora onde irá hidratar e prevenir os fios dos Cílios durando o dia todo, na remoção com água morna no banho ou com demaquilante ela solta a cápsula em cubinhos trazendo maior conforto e praticidade para o seu dia a dia.'),(4,'Chuteira Nike ','Phantom GT2 Elite Campo','899','Artigos Esportivos','Continuando o legado da Phantom GT, a Nike Phantom GT2 Elite FG apresenta um design atualizado e um padrão em relevo projetado para otimizar seus movimentos e controlar o voo da bola. Os cadarços descentralizados criam uma zona de chute livre de obstáculos para chutes, passes e dribles habilidosos.'),(5,'Fritadeira Air Fry Britânia ','Pro Saúde Preta','349','Cozinha e Eletrodomesticos','O que era inimaginável agora é real, sim, você pode fritar alimentos sem usar óleo, sem deixar cheiro de gordura ou fumaça pela casa, e tem mais, você também pode preparar alimentos de maneira incrivelmente rápida e deixar tudo crocante, gostoso e mais saudável para a sua família! Com a incrível Fritadeira Elétrica Sem Óleo Air Fryer AF-31 New Pratic Preta da Mondial feita em PP, com capacidade total de 3,6L, tudo isso está ao seu alcance. Painel digital touch screen que facilita a escolha das funções de tempo e temperatura, lâmpadas-piloto que indicam o funcionamento do produto e do aquecimento, controle de temperatura até 200 oC para a escolha da temperatura ideal de acordo com diferentes tipos de alimentos..'),(6,'Teclado Gamer Mecânico','Hoopson Branco RGB','199','Laptops & Notebooks','Um Teclado de alto desempenho permite que você desfrute de horas ilimitadas de jogos. Foi especialmente desenvolvido para que você possa expressar suas habilidades e seu estilo. Melhore a sua experiência de jogo, seja você um amador ou um especialista.'),(7,'Panela Redonda','Signature Le Creuset','1.499','Cozinha e Eletrodomesticos','Icônica, a panela Le Creuset Redonda Signature é um clássico da marca e indispensável para sua casa.'),(8,'Iphone 13','256gb','5.299','Smartphones','Phone 13. O sistema de câmera dupla mais avançado em um iPhone. Chip A15 Bionic com velocidade impressionante. Um grande salto em bateria. Projetado para durar. 5G ultrarrápido*. E tela Super Retina XDR mais brilhante. Avisos legais: *É preciso ter um plano de dados. 5G só está disponível em alguns países e por meio de determinadas operadoras. As velocidades variam de acordo com as condições e operadoras locais. Para obter detalhes sobre a compatibilidade com 5G, entre em contato com sua operadora e consulte apple.com/br/iphone/cellular.'),(9,'Kit Fortificante Capilar','Com Shampoo e Máscara','349','Beleza e Maquiagem','O Kit de Alho promove o fortalecimento e reparação profunda dos cabelos de dentro para fora. É a combinação perfeita e equilibrada de ativos naturais que auxiliam no crescimento saudável dos cabelos. Liberado para LOW POO.');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-02 15:25:14
