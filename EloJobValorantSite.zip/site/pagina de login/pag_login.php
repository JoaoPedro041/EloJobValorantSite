<?php

$email = $_POST["email"];
$senha = $_POST["senha"];

include "pag_lo_conexao.php";

$query = "SELECT * FROM credencial WHERE email = '$email' and senha = '$senha'";

$resultado_query = mysqli_query($con,$query);

if(mysqli_num_rows($resultado_query) > 0)
{   
    $retorno["status"] = "s";
}
else
{   

    $retorno["status"] = "n";
}

$objetoJSON = json_encode($retorno);
echo $objetoJSON;

?>