function Acessar(){
    var form = document.getElementById("formEntrar");
    var dados = new FormData(form);
    fetch("pag_login.php", { 
        method: "POST",
        body: dados 
    }).then(async function (resposta) {
        var objeto = await resposta.json();

        if(objeto.status == "s"){
            window.location.href = "../pagina principal/pag_principal.html";
        }
        else{
            alert("Usuario nao cadastrado");
        }
    });;
}
function cadastro(){
    window.location.href = "cadastro.html";
}