function gravar(){

    var form = document.getElementById("formCadastro");
    var dados = new FormData(form);

    fetch("pag_cadastro.php", {
        method: "POST",
        body: dados
    });
}


