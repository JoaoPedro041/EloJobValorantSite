<?php

    include "pag_ca_conexao.php";

    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $query = "INSERT INTO credencial (nome, cpf, email, senha) VALUES ('$nome','$cpf','$email','$senha')";

    mysqli_query($con, $query);

?>